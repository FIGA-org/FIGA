export const founder = {
    name: "Elena Torres Villanueva",
    title: "Lic. en Derechos Humanos / ONG",
    bio: `Lidero la Fundación Internacional Granito de Arena en Chiapas...`,
    photo: "/images/founder.jpg",
    carrd: "https://elenatorresv.carrd.co/",
  };
  
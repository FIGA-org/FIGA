export const recognitions = [
    "Mención Honorífica por el Ejecutivo Federal (DOF), 2022",
    "Premio Nacional al Liderazgo Social, 2021",
    "Premio Municipal de la Juventud, Tuxtla Gutiérrez, 2020",
    "Semifinalista Premio UVM por el Desarrollo Social, 2013",
    "Distinción “Joven Defensora de la Infancia Chiapaneca”, CMDPDH, 2011",
    "Mención honorífica en Premios Regionales de Derechos Humanos, 2018",
  ];
  
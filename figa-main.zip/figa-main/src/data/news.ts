// export const NEWS_PLACEHOLDER_SOURCE = {
//     name: "CBC News – Top Stories",
//     url: "https://www.cbc.ca/cmlink/rss-topstories",     // placeholder feed
//     homepage: "https://www.cbc.ca/news",
//   };
  
//   // Tweak how many items you want
//   export const NEWS_LIMIT = 6;
//   export const NEWS_REVALIDATE_SECONDS = 600; // 10 min cache
  